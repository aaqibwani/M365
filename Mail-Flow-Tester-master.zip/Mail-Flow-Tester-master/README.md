# Mail-Flow-Tester
This application is used to send email messages for mail flow testing. I work as a support engineer with Microsoft and support Exchange Online. I often have the need to send email messages to particular endpoints. I was tired of using Telnet for this and developed this application to assist in my work.

[Mail Flow Tester read me.docx](https://github.com/SeriousSneak/Mail-Flow-Tester/files/7609081/Mail.Flow.Tester.read.me.docx)

![MFT screenshot](https://user-images.githubusercontent.com/48761543/143590414-42454a76-de7c-4f28-86f4-b0ddcac8cc31.png)
